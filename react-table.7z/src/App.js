import './App.css';
import React, { useEffect, useState } from 'react';
import Search from './Search';
import ProductTable from './ProductTable';
function App() {
  const [filterredData, setFilteredData] = useState([]);
  const data = React.useMemo(() =>
    [
      {
        name: 'Kim Parrish',
        address: '4420 Valley Street, Garnerville, NY 10923',
        date: '07/11/2020',
        order: '87349585892118',
      },
      {
        name: 'Michele Castillo',
        address: '637 Kyle Street, Fullerton, NE 68638',
        date: '07/11/2020',
        order: '58418278790810',
      },
      {
        name: 'Eric Ferris',
        address: '906 Hart Country Lane, Toccoa, GA 30577',
        date: '07/10/2020',
        order: '81534454080477',
      },
      {
        name: 'Gloria Noble',
        address: '2403 Edgewood Avenue, Fresno, CA 93721',
        date: '07/09/2020',
        order: '20452221703743',
      },
      {
        name: 'Darren Daniels',
        address: '882 Hide A Way Road, Anaktuvuk Pass, AK 99721',
        date: '07/07/2020',
        order: '22906126785176',
      },
      {
        name: 'Ted McDonald',
        address: '796 Bryan Avenue, Minneapolis, MN 55406',
        date: '07/07/2020',
        order: '87574505851064',
      },
    ],
    []
  )
  useEffect(()=>{
    setFilteredData(products)
  },[])
  const headers = React.useMemo(
    () => ['Name', 'Address', 'Date', 'Order'],
    [])
  const searchHandler = (searchTerm) => {
    console.log(searchTerm);
    if (searchTerm !== "") {
      const result = products.filter((d) => {
        return ( d.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        d.price.toString().toLowerCase().includes(searchTerm.toLowerCase())  ||
        d.stock.toString().toLowerCase().includes(searchTerm.toLowerCase()) )
      })
      setFilteredData(result)
    }else{
      setFilteredData(products)
    }
  }
  const  products=[
    { id: 1, name: 'Cheese', price: 4.9, stock: 20 },
    { id: 2, name: 'Milk', price: 1.9, stock: 32 },
    { id: 3, name: 'Yoghurt', price: 2.4, stock: 12 },
    { id: 4, name: 'Heavy Cream', price: 3.9, stock: 9 },
    { id: 5, name: 'Butter', price: 0.9, stock: 99 },
    { id: 6, name: 'Sour Cream ', price: 2.9, stock: 86 },
    { id: 7, name: 'Fancy French Cheese 🇫🇷', price: 99, stock: 12 },
  ]
  return (
    <div className="App">
      <Search searchHandler={searchHandler} />
      <ProductTable
        products  ={filterredData}
      />
    </div>
  );
}

export default App;
