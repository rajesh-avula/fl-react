
import React from 'react';
import useSortableData from './Sort';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
function ProductTable(props) {
    const { items, requestSort, sortConfig } = useSortableData(props.products);
    return (
        <table>
            <thead>
                <tr style={{"border-bottom" : "1px solid black"}}>
                    <th onClick={() => requestSort('name')}>Name
                        {sortConfig ? sortConfig.direction === 'ascending' && <KeyboardArrowUpIcon /> : null}
                        {sortConfig ? sortConfig.direction === 'descending' && <KeyboardArrowDownIcon /> : null}
                    </th>
                    <th onClick={() => requestSort('price')}>
                        Price
                        {sortConfig ? sortConfig.direction === 'ascending' && <KeyboardArrowUpIcon /> : null}
                        {sortConfig ? sortConfig.direction === 'descending' && <KeyboardArrowDownIcon /> : null}

                    </th>
                    <th onClick={() => requestSort('stock')}>
                        In Stock
                        {sortConfig ? sortConfig.direction === 'ascending' && <KeyboardArrowUpIcon /> : null}
                        {sortConfig ? sortConfig.direction === 'descending' && <KeyboardArrowDownIcon /> : null}
                    </th>
                </tr>
            </thead>
            <tbody>
                {items.map((item) => (
                    <tr key={item.id}>
                        <td>{item.name}</td>
                        <td>${item.price}</td>
                        <td>{item.stock}</td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
};

export default ProductTable;