import { Button, TextField } from '@material-ui/core';
import React, { useState } from 'react';

function Search(props) {
    const [searchValue,setSearchValue] = useState("");
    return (
        <div style={{ display: "flex"}}>
        <TextField id="outlined-basic" variant="outlined" onChange={(e) => setSearchValue(e.target.value)}/>
        <Button variant="outlined" onClick={() => props.searchHandler(searchValue)} style={{"margin-left" : "1em"}}>SEARCH</Button>
        </div>
    );
}

export default Search;